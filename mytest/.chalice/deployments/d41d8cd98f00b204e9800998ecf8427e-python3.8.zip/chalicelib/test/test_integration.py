import json
from http import HTTPStatus

import pytest

from chalicelib import factories, models


class TestMyTest:

    def test_inserts_user_record(self, db_session):
        # Given
        first_name = "Hank"

        # When
        new_user = factories.UserFactory(db_session).create(
            **{
                "first_name": first_name
            }
        )
        # Get the resulting record
        rec = (
            db_session.query(models.User)
                .filter(models.User.first_name == first_name)
                .first()
        )

        # Then
        # Check record has been created OK
        assert new_user.first_name == rec.first_name
        assert new_user.user_id == rec.user_id

    def test_index(self, gateway_factory):
        gateway = gateway_factory()
        response = gateway.handle_request(method="GET",
                                          path="/",
                                          headers={"Accept": "application/json"},
                                          body="")
        assert response["statusCode"] == 200
        assert json.loads(response["body"]) == dict([("hello", "world")])
